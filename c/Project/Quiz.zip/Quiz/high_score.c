/*
                        QUIZ PROGRAM
                SREYAS ENGINEERING COLLEGE

                        DEVELOPED
                            
                            BY

                        M ANURAG 
                        B AKSHITHA
                        A SIDDHARTHA
                        B JAHNAVI
                        K ARYAN
                        B NIKETH
*/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "quiz.h"

void high_scores()
{
    // read profile.dbs file and find top 10 scorers and list rank, name, date, level, score.

    FILE *fp = fopen(USER_PROFILE_FILE, "rb");

    if(fp == NULL)
    {
        printf("Failed to open profile");
        return;
    }

    user_profile up;
    size_t sz = 0;
    int rank = 0;
    do
    {
        
        if((sz = fread(&up, sizeof(user_profile), 1, fp)) != 0)
        {
            printf("%d\t%s\t%s\t%d\t%d\n", rank++, up.name, up.date, up.level, up.score);
        }
        
    } while (sz != 0);

    fclose(fp);
}


